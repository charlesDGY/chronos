dir=$1
cd $dir
rm loop.info
rm *.cfg
