java  -jar gui.jar
