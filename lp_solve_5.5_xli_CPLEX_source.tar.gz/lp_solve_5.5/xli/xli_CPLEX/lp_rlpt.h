extern lprec *read_lptex(lprec *lp, FILE *filename, int verbose, char *lp_name);
extern lprec * __WINAPI read_lpt(FILE *filename, int verbose, char *lp_name);
extern lprec *read_LPTex(lprec *lp, char *filename, int verbose, char *lp_name);
extern lprec * __WINAPI read_LPT(char *filename, int verbose, char *lp_name);
