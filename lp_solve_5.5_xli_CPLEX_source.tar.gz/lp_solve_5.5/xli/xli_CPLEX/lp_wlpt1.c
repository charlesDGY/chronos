#define LPSOLVEAPIFROMLPREC

#include "lp_explicit.h"

#define mat_validate(matA) TRUE

#include "lp_wlpt.c"
