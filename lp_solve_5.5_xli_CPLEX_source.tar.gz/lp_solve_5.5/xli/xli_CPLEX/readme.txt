This directory contains the files to build XLI CPLEX library.

This library allows lp_solve to read and write model files in the CPLEX lp format.

See http://www.rpi.edu/dept/math/math-programming/cplex66/sun4x_56/doc/refman/html/appendixE12.html
for a description about the CPLEX lp format.

To build the program under Windows with the Visual C/C++ compiler, use cvc6.bat (also works for VS.NET)
To build the program under Linux/Unix, use sh ccc
