#include "lp_lib.h"

extern MYBOOL __EXPORT_TYPE __WINAPI write_lpt(lprec *lp, char *filename);
