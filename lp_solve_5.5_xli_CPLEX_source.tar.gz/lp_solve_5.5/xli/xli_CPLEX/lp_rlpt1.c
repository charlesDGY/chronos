#define LPSOLVEAPIFROMLPREC

#include "lp_explicit.h"

#include "lp_rlpt.c"
