#ifndef HEADER_lp_lp
#define HEADER_lp_lp

/* Include libraries for this language system */
#include "lp_types.h"
/*#include "lusol.h"*/


#ifdef __cplusplus
namespace lp
extern "C" {
#endif

/* Put function headers here */
#include "lp_XLI.h"

#ifdef __cplusplus
 }
#endif

#endif /* HEADER_lp_lp */
