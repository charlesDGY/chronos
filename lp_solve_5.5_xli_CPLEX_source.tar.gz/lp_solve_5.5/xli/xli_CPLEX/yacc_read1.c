#define LPSOLVEAPIFROMLPREC

#include "lp_explicit.h"

#include "yacc_read.c"
